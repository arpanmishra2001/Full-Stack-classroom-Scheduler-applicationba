  <hr>

      <footer>
        <p>Copyright &copy; Carlos Hilado Memorial State College All rights reserved.</p>
		<div class="pull-right_foot">
		Programmed by: John kevin Lorayna :-P
		</div>
		
      </footer>